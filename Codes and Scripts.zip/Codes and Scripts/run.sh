Author: Dr. Wei Xiao
Institution: Division of Pulmonary Medicine, Department of Internal Medicine, Institute of Integrated Traditional Chinese and Western Medicine, West China Hospital
E-mail: weifly@scu.edu.cn

###################################################################################################################################################################
Step1\ Microbiome data processing and ecological analysis\ Environment: QIIME2 v2019.7

#Note: This part displays how to perform microbiome data processing and ecological analysis on n=187 subjects of the EndAECOPD cohort 
#Import 16S data to qiime
#Place all demultiplexed and merged sequencing data into the same folder; in this example: RawReads.
mkdir Import2QIIME
cd Import2QIIME
conda activate qiime2-2019.7
import2qiime.pl ../RawReads/*.gz

#Denoise data
cd ..
mkdir Denoise
cd Denoise
mkdir logs
qiime dada2 denoise-single \
  --i-demultiplexed-seqs ../Import2QIIME/seqs.qza \
  --o-representative-sequences seqs.qza \
  --o-table table.qza \
  --o-denoising-stats  seq.stats.qza \
  --p-trunc-len 0 --p-n-threads 44
  
perl -e 'print "#SampleID\tGroup\tSubjectID\tStudy\t\n#q2:types\tcategorical\tcategorical\tcategorical\n"' > header.tsv
cut -f 1 -d',' ../02.Import2QIIME/manifest.txt  | sort | uniq | grep -v "sample-id" | perl -lne 'my @meta = split /\./;  $meta[1] = sprintf "%04d", $meta[1]; $sample = join ".", @meta; print join "\t", $sample, @meta;' | cat header.tsv - > metadata.tsv     #generate metadata file

qiime feature-table summarize \
  --i-table table.qza \
  --o-visualization table.qzv \
  --m-sample-metadata-file metadata.tsv

qiime feature-table tabulate-seqs \
  --i-data seqs.qza \
  --o-visualization rep-seqs.qzv
  
qiime metadata tabulate \
  --m-input-file seq.stats.qza \
  --o-visualization seq.stats.qzv
  
#Remove potential contaminants
cd ..
mkdir FilterTaxonomic
cd FilterTaxonomic
qiime feature-classifier classify-sklearn \
  --i-classifier gg-13-8-99-nb-classifier.qza \
  --i-reads ../Denoise/seqs.qza \
  --o-classification taxonomy.qza \
  --p-n-jobs 44
  
qiime taxa filter-table \
  --i-table ../Denoise/table.qza \
  --i-taxonomy taxonomy.qza \
  --p-include p__ \
  --p-exclude mitochondria,chloroplast,unassigned,eukaryota,archaea \
  --o-filtered-table table.qza
  
qiime feature-table filter-seqs --i-data ../Denoise/seqs.qza --i-table table.qza --o-filtered-data seqs.qza

#Rarefaction
cd ..
mkdir Rarefaction
cd Rarefaction
qiime feature-table rarefy \
  --i-table ../FilterTaxonomic/table.qza \
  --p-sampling-depth 20799 \
  --o-rarefied-table tables.qza

qiime feature-table summarize \
  --i-table tables.qza \
  --o-visualization tables.qzv \
  --m-sample-metadata-file ../Denoise/metadata.tsv

qiime feature-table filter-seqs --i-data ../FilterTaxonomic/seqs.qza \
  --i-table tables.qza \
  --o-filtered-data seqs.qza 

qiime feature-table tabulate-seqs \
  --i-data seqs.qza \
  --o-visualization seqs.qzv
  
#Taxonomic profiling
cd ..
mkdir Taxonomic
cd Taxonomic
qiime feature-classifier classify-sklearn \
  --i-classifier gg-13-8-99-nb-classifier.qza \
  --i-reads ../Rarefaction/seqs.qza \
  --o-classification taxonomy.qza \
  --p-n-jobs 44
   
qiime metadata tabulate \
  --m-input-file taxonomy.qza \
  --o-visualization taxonomy.qzv

qiime taxa barplot \
  --i-table ../Rarefaction/tables.qza \
  --i-taxonomy taxonomy.qza \
  --o-visualization Barplot.qzv \
  --m-metadata-file ../Denoise/metadata.tsv

qiime taxa collapse \
  --i-table ../Rarefaction/tables.qza \
  --i-taxonomy taxonomy.qza \
  --p-level 6 \
  --o-collapsed-table tables-genus.qza

qiime feature-table relative-frequency \
  --i-table tables-genus.qza \
  --o-relative-frequency-table abundance-genus.qza

qiime tools export \
  --input-path abundance-genus.qza \
  --output-path .

#Generate phylogenetic tree
cd ..
mkdir Phylogeny
cd Phylogeny
qiime phylogeny align-to-tree-mafft-fasttree \
  --i-sequences  ../Rarefaction/seqs.qza \
  --o-alignment aligned-seqs.qza \
  --o-masked-alignment masked-aligned-seqs.qza \
  --o-tree unrooted-tree.qza \
  --o-rooted-tree rooted-tree.qza \
  --p-n-threads 44
  
#Diversity analysis
cd ..
mkdir Diversity
cd Diversity
qiime diversity core-metrics-phylogenetic \
  --i-phylogeny ../Phylogeny/rooted-tree.qza \
  --i-table ../Rarefaction/tables.qza \
  --p-sampling-depth 20799 \
   --p-n-jobs 44 \
  --m-metadata-file ../Denoise/metadata.tsv \
  --output-dir CoreMatrix
  
mkdir Alpha Beta
qiime diversity alpha-group-significance \
  --i-alpha-diversity CoreMatrix/shannon_vector.qza \
  --m-metadata-file ../Denoise/metadata.tsv \
  --o-visualization Alpha/shannon-vector-group-significance.qzv

qiime diversity beta-group-significance \
  --i-distance-matrix CoreMatrix/weighted_unifrac_distance_matrix.qza \
  --m-metadata-file ../Denoise/metadata.tsv \
  --m-metadata-column Group \
  --o-visualization Beta/weighted-unifrac-Group-significance.qzv
  

#LEfSe analysis
cd ..
mkdir LEfSe
cd LEfSe
conda deactivate
conda activate lefse
qiime_collapse_to_lefse.pl -m ../Denoise/metadata.tsv -a ../Taxonomic/abundance-genus.tsv -c Group | filter_row_by_frequency.pl -f 0.0005 -h 2 |  filter_row_by_min.pl -f 0 -h 2 -n 0.05 >LEFSe-genus.txt
format_input.py LEFSe-genus.txt LEFSe-genus.in -c 1 -s -1 -u 2 -o 1000000
run_lefse.py LEFSe-genus.in LEFSe-genus.res
plot_res.py LEFSe-genus.res LEFSe-genus.pdf --format pdf
plot_cladogram.py LEFSe-genus.res LEFSe-genus.cladogram.pdf --format pdf


###################################################################################################################################################################
Step2\ Microbial co-occurrence network analysis\ Environment: Python 2.7.16; R 4.1.0.

#Note: This part displays how to implement the co-occurence analysis on n=187 subjects of the EndAECOPD cohort 
#Place Abundance.csv and labels.csv in EnsembleNet file
cd EnsembleNet
python collate.py
cd Bray-Curtis/
Rscript bray-curtis.R
cd ..
cd GBLM/
Rscript GBLM.R
cd ..
cd MI/
Rscript MI.R
cd ../Pearsons
Rscript pearsons.R
cd ../Spearman
Rscript spearman.R
cd ..
echo "All done"
cd ./Merge_p-val_scores/   
Rscript Merge.R 
python Adjacency_matrix_creator.py

###################################################################################################################################################################
Step3\ Spectral clustering analysis\ Environment: R 4.1.0.

#Note: This part displays how to perform network clustering on n=143 COPD patients of the EndAECOPD cohort
#Place COPD_abundance.csv and labels.csv in SpectralClustering file
cd SpectralClustering
mkdir results
Rscript snf.R
Rscript heatmap.R
