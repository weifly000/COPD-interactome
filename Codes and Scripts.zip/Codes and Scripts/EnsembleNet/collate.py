from __future__ import division
import pandas

bac=pandas.read_csv("Abundance.csv",index_col=0)
lab=pandas.read_csv("labels.csv",index_col=0)

df=bac.join(lab,how="inner")

nsel=df.sum(axis=0)
n=nsel[nsel<0.1122].index   #0.0006*187
df.drop(columns=n,inplace=True)

nsel=df>0
nsel=nsel.sum(axis=0)
y=nsel[nsel<10].index #0.05*187
df.drop(columns=y,inplace=True)

df.rename(columns={"labels":"x"},inplace=True)
df.to_csv("Microbes.csv")
#Manually add PatientID as the index column name
