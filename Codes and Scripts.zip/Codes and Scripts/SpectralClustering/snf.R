library("SNFtool")
library("vegan")
library("reticulate")
use_python("/usr/bin/python")
source_python("sil.py")
source("modified_est-cluster.R")

data=read.csv("COPD_abundance.csv",row.names = 1)

#Filtering the data
list_sel=list()
count=1
for (d in list(data)){
  z=colSums(d>0)
  sel_col=row.names(as.data.frame(z[z>=7])) #In 5% patients prevalent
  #print(sel_col)
  list_sel[[count]]<-sel_col
  count=count+1
}

data<-data[,list_sel[[1]]]
#f_data<-f_data[,list_sel[[2]]]
#v_data<-v_data[,list_sel[[3]]]
remove(d,list_sel,count,sel_col,z)

b_dsim=vegdist(data,method='bray',diag=TRUE,upper=TRUE)
#f_dsim=vegdist(f_data,method='bray',diag=TRUE,upper=TRUE)
#v_dsim=vegdist(v_data,method='bray',diag=TRUE,upper=TRUE)

#v_dsim[is.nan(v_dsim)]<-0 #As disimilarity is zero if both patients dont have any virus

W=(as.matrix(b_dsim)-1)*-1
#W2=(as.matrix(f_dsim)-1)*-1
#W3=(as.matrix(v_dsim)-1)*-1


names=c("bacteria")
count<-1
for (x in list(W)){
  print(names[count])
  y<-estimateNumberOfClustersGivenGraph(x)
  print("First best")
  labels=spectralClustering(x,y$`Eigen-gap best`)
  print(table(labels))
  print("second best")
  labels=spectralClustering(x,y$`Eigen-gap 2nd best`)
  print(table(labels))
  count<-count+1
  }
#From the above output we identify these as the optimum number of clusters
clusters=c(2)
count<-1
for (x in list(W)){
labels=spectralClustering(x,clusters[count])
lab=as.data.frame(labels,row.names = row.names(data))
print(silhouette_score(x,labels))
write.csv(lab,paste('./results/',names[count],"_labels",".csv",sep=''))
write.csv(x,paste('./results/',names[count],"_matrix",".csv",sep=''))
count=count+1
}

#Bootstrap-robustness test
cluster<-function(W,indices,z=2){
  W<-W[indices,indices]
  labels=spectralClustering(W,z)
  lab=as.data.frame(labels,row.names = row.names(W))
  return(lab)
}
is.even <- function(x) x %% 2 == 0
is.odd <- function(x) x %% 2 != 0

misclassification_ratio=c()

for (i in 1:100){
  ind<-sample(row.names(W),round(0.7*(dim(W)[1])))
  l=cluster(W,ind)
  com=merge(lab,l,by="row.names",all.y = TRUE);row.names(com)<-com$Row.names;com$Row.names<-NULL
  if ( sum(is.odd(rowSums(com)))>sum(is.even(rowSums(com))) ) {
    mis<-sum(is.even(rowSums(com)))
  }
  else{
    mis<-sum(is.odd(rowSums(com)))
  }
  misclassification_ratio=c(misclassification_ratio,mis/(dim(com)[1]))
}

print(1-mean(misclassification_ratio))