library(ggplot2)
library(pheatmap)

bac_matrix <-read.csv("Results/bacteria_matrix.csv",header = T,row.names = 1)
annotation_col <- read.csv("Results/bacteria_labels.csv",header = T,row.names = 1)
pdf("heatmap_SNF.pdf", width = 6, height = 6)
p_similarity <- pheatmap(bac_matrix, 
                    border="white", 
                    cluster_cols = F, 
                    cluster_rows = F, 
                    show_rownames = F,
                    show_colnames = F,
                    fontsize = 6,
                    angle_col = 90,
                    annotation_col = annotation_col,
                    width = 6,
                    height = 6)
p_similarity
dev.off()
graphics.off()